
  <div ng-message="required">必填项</div>
  <div ng-message="minlength">输入太短</div>
  <div ng-message="maxlength">超过长度限制</div>
  <div ng-message="email">You have entered an incorrect email value</div>
  <div ng-message="pattern">You did not enter the value in the correct format</div>
  <div ng-message="password-characters">
    密码需要包含数字、小写字母
  </div>